import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const airQualityData = [
  { location: 'Downtown', pm25: 45, pm10: 65, no2: 35, o3: 55, aqi: 78 },
  { location: 'Midtown', pm25: 38, pm10: 58, no2: 28, o3: 62, aqi: 71 },
  { location: 'Uptown', pm25: 25, pm10: 40, no2: 18, o3: 48, aqi: 52 },
  { location: 'Industrial', pm25: 68, pm10: 85, no2: 55, o3: 42, aqi: 95 },
  { location: 'Residential', pm25: 32, pm10: 45, no2: 22, o3: 38, aqi: 58 },
  { location: 'Park Area', pm25: 18, pm10: 25, no2: 12, o3: 35, aqi: 42 },
];

export const AirQualityChart = () => {
  return (
    <Card className="bg-dashboard-surface border-border">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-foreground">
          Air Quality Distribution
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Pollutant levels and AQI across different city zones
        </p>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={airQualityData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="location" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                angle={-45}
                textAnchor="end"
                height={60}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'hsl(var(--dashboard-elevated))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                  color: 'hsl(var(--foreground))'
                }}
                labelStyle={{ color: 'hsl(var(--foreground))' }}
              />
              <Legend />
              <Bar 
                dataKey="pm25" 
                fill="hsl(var(--chart-1))" 
                name="PM2.5 (μg/m³)"
                radius={[2, 2, 0, 0]}
              />
              <Bar 
                dataKey="pm10" 
                fill="hsl(var(--chart-2))" 
                name="PM10 (μg/m³)"
                radius={[2, 2, 0, 0]}
              />
              <Bar 
                dataKey="no2" 
                fill="hsl(var(--chart-3))" 
                name="NO₂ (ppb)"
                radius={[2, 2, 0, 0]}
              />
              <Bar 
                dataKey="aqi" 
                fill="hsl(var(--chart-5))" 
                name="AQI"
                radius={[2, 2, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};