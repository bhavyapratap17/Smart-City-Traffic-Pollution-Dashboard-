import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const trafficData = [
  { time: '00:00', density: 15, avgSpeed: 65, congestion: 8 },
  { time: '02:00', density: 8, avgSpeed: 70, congestion: 5 },
  { time: '04:00', density: 12, avgSpeed: 68, congestion: 6 },
  { time: '06:00', density: 45, avgSpeed: 35, congestion: 75 },
  { time: '08:00', density: 85, avgSpeed: 22, congestion: 95 },
  { time: '10:00', density: 60, avgSpeed: 45, congestion: 65 },
  { time: '12:00', density: 70, avgSpeed: 40, congestion: 70 },
  { time: '14:00', density: 55, avgSpeed: 50, congestion: 60 },
  { time: '16:00', density: 75, avgSpeed: 30, congestion: 85 },
  { time: '18:00', density: 90, avgSpeed: 25, congestion: 90 },
  { time: '20:00', density: 50, avgSpeed: 55, congestion: 45 },
  { time: '22:00', density: 30, avgSpeed: 60, congestion: 25 },
];

export const TrafficChart = () => {
  return (
    <Card className="bg-dashboard-surface border-border">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-foreground">
          Traffic Patterns - Downtown District
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Real-time traffic density, average speed, and congestion levels
        </p>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trafficData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="time" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'hsl(var(--dashboard-elevated))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                  color: 'hsl(var(--foreground))'
                }}
                labelStyle={{ color: 'hsl(var(--foreground))' }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="density" 
                stroke="hsl(var(--chart-1))" 
                strokeWidth={3}
                name="Traffic Density (%)"
                dot={{ fill: 'hsl(var(--chart-1))', strokeWidth: 2, r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="avgSpeed" 
                stroke="hsl(var(--chart-2))" 
                strokeWidth={3}
                name="Avg Speed (km/h)"
                dot={{ fill: 'hsl(var(--chart-2))', strokeWidth: 2, r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="congestion" 
                stroke="hsl(var(--chart-5))" 
                strokeWidth={3}
                name="Congestion Level (%)"
                dot={{ fill: 'hsl(var(--chart-5))', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};