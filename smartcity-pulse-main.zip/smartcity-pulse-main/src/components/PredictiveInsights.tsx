import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Clock, Route } from "lucide-react";

const insights = [
  {
    id: 1,
    type: 'optimal',
    icon: CheckCircle,
    title: 'Optimal Travel Time',
    description: 'Best window for downtown commute: 10:30 AM - 11:30 AM',
    prediction: '15% faster than peak hours',
    confidence: 92,
    iconColor: 'text-air-good'
  },
  {
    id: 2,
    type: 'warning',
    icon: AlertTriangle,
    title: 'Air Quality Alert',
    description: 'PM2.5 levels expected to rise in Industrial sector',
    prediction: 'AQI may reach 110+ by 3:00 PM',
    confidence: 87,
    iconColor: 'text-air-moderate'
  },
  {
    id: 3,
    type: 'route',
    icon: Route,
    title: 'Route Optimization',
    description: 'Alternative route via Park Avenue reduces emissions by 25%',
    prediction: '8 min longer but 40% cleaner air exposure',
    confidence: 95,
    iconColor: 'text-chart-2'
  },
  {
    id: 4,
    type: 'trend',
    icon: TrendingDown,
    title: 'Traffic Reduction',
    description: 'Evening rush hour showing 12% improvement this week',
    prediction: 'Congestion levels trending downward',
    confidence: 89,
    iconColor: 'text-air-good'
  }
];

export const PredictiveInsights = () => {
  return (
    <Card className="bg-dashboard-surface border-border">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-foreground flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-primary" />
          Predictive Insights
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          AI-powered recommendations for optimal routes and timing
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {insights.map((insight) => {
            const IconComponent = insight.icon;
            return (
              <div 
                key={insight.id}
                className="p-4 rounded-lg bg-gradient-accent border border-border/50 hover:bg-dashboard-elevated transition-smooth group"
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg bg-dashboard-elevated ${insight.iconColor}`}>
                    <IconComponent className="w-4 h-4" />
                  </div>
                  
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-foreground group-hover:text-primary transition-smooth">
                        {insight.title}
                      </h4>
                      <Badge 
                        variant="secondary" 
                        className="text-xs bg-dashboard-elevated text-muted-foreground"
                      >
                        {insight.confidence}% confidence
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-muted-foreground">
                      {insight.description}
                    </p>
                    
                    <p className="text-sm font-medium text-primary">
                      {insight.prediction}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-6 p-4 rounded-lg bg-gradient-primary/10 border border-primary/20">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Next Update</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Predictions refreshed every 15 minutes using real-time traffic and environmental data
          </p>
        </div>
      </CardContent>
    </Card>
  );
};