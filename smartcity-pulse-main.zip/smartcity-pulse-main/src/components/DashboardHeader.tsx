import { Calendar, MapPin, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const DashboardHeader = () => {
  const currentDate = new Date();
  const timeString = currentDate.toLocaleTimeString('en-US', { 
    hour: '2-digit', 
    minute: '2-digit',
    hour12: false 
  });
  const dateString = currentDate.toLocaleDateString('en-US', { 
    weekday: 'long',
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  return (
    <header className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8">
      <div className="space-y-2">
        <h1 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent">
          Smart City Pulse
        </h1>
        <p className="text-muted-foreground text-lg">
          Real-time Traffic & Environmental Analytics Dashboard
        </p>
      </div>
      
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="w-4 h-4" />
          <span>{timeString}</span>
          <span className="text-primary">•</span>
          <Calendar className="w-4 h-4" />
          <span>{dateString}</span>
        </div>
        
        <div className="flex items-center gap-3">
          <Select defaultValue="downtown">
            <SelectTrigger className="w-[180px] bg-dashboard-surface border-border">
              <MapPin className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-dashboard-surface border-border">
              <SelectItem value="downtown">Downtown District</SelectItem>
              <SelectItem value="midtown">Midtown Area</SelectItem>
              <SelectItem value="uptown">Uptown Zone</SelectItem>
              <SelectItem value="industrial">Industrial Sector</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="outline" 
            className="bg-dashboard-surface border-border hover:bg-dashboard-elevated transition-smooth"
          >
            Export Data
          </Button>
        </div>
      </div>
    </header>
  );
};