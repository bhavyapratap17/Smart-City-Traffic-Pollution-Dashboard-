import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: LucideIcon;
  iconColor?: string;
  subtitle?: string;
}

export const MetricCard = ({ 
  title, 
  value, 
  change, 
  changeType, 
  icon: Icon, 
  iconColor = "text-primary",
  subtitle 
}: MetricCardProps) => {
  return (
    <Card className="bg-dashboard-surface border-border hover:shadow-elevated transition-smooth group">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={cn("p-2 rounded-lg bg-gradient-accent", iconColor)}>
            <Icon className="w-5 h-5" />
          </div>
          <div className={cn(
            "text-sm font-medium px-2 py-1 rounded-full",
            changeType === 'positive' && "text-air-good bg-air-good/10",
            changeType === 'negative' && "text-air-poor bg-air-poor/10",
            changeType === 'neutral' && "text-muted-foreground bg-muted/10"
          )}>
            {change}
          </div>
        </div>
        
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
            {title}
          </h3>
          <p className="text-3xl font-bold text-foreground group-hover:text-primary transition-smooth">
            {value}
          </p>
          {subtitle && (
            <p className="text-sm text-muted-foreground">
              {subtitle}
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};