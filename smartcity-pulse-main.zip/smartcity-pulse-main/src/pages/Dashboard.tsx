import { Car, Wind, Thermometer, Activity, MapPin, Users, TrendingUp, Zap } from "lucide-react";
import { DashboardHeader } from "@/components/DashboardHeader";
import { MetricCard } from "@/components/MetricCard";
import { TrafficChart } from "@/components/TrafficChart";
import { AirQualityChart } from "@/components/AirQualityChart";
import { PredictiveInsights } from "@/components/PredictiveInsights";
import smartCityHero from "@/assets/smart-city-hero.jpg";

const Dashboard = () => {
  return (
    <div className="min-h-screen bg-dashboard-bg">
      {/* Hero Section */}
      <div 
        className="relative h-64 bg-cover bg-center flex items-center justify-center"
        style={{ backgroundImage: `url(${smartCityHero})` }}
      >
        <div className="absolute inset-0 bg-dashboard-bg/80"></div>
        <div className="relative z-10 text-center space-y-4">
          <h1 className="text-5xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Smart City Pulse
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl">
            Real-time analytics for traffic optimization and environmental monitoring
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8 space-y-8">
        <DashboardHeader />
        
        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Traffic Flow"
            value="1,247"
            change="+12.5%"
            changeType="positive"
            icon={Car}
            iconColor="text-chart-1"
            subtitle="vehicles/hour"
          />
          <MetricCard
            title="Air Quality Index"
            value="68"
            change="-8.2%"
            changeType="positive"
            icon={Wind}
            iconColor="text-air-moderate"
            subtitle="Moderate level"
          />
          <MetricCard
            title="Average Speed"
            value="42 km/h"
            change="+15.3%"
            changeType="positive"
            icon={Activity}
            iconColor="text-chart-2"
            subtitle="city-wide"
          />
          <MetricCard
            title="CO₂ Emissions"
            value="2.8 tons"
            change="-22.1%"
            changeType="positive"
            icon={Zap}
            iconColor="text-air-good"
            subtitle="per hour"
          />
        </div>

        {/* Secondary Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Active Sensors"
            value="346"
            change="99.2%"
            changeType="positive"
            icon={MapPin}
            iconColor="text-primary"
            subtitle="operational"
          />
          <MetricCard
            title="Peak Hour Factor"
            value="0.85"
            change="-5.8%"
            changeType="positive"
            icon={TrendingUp}
            iconColor="text-chart-3"
            subtitle="efficiency index"
          />
          <MetricCard
            title="Daily Commuters"
            value="127K"
            change="+3.4%"
            changeType="neutral"
            icon={Users}
            iconColor="text-chart-4"
            subtitle="tracked today"
          />
          <MetricCard
            title="Temperature"
            value="23°C"
            change="+2.1%"
            changeType="neutral"
            icon={Thermometer}
            iconColor="text-air-moderate"
            subtitle="city average"
          />
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          <TrafficChart />
          <AirQualityChart />
        </div>

        {/* Insights Section */}
        <PredictiveInsights />
      </div>
    </div>
  );
};

export default Dashboard;